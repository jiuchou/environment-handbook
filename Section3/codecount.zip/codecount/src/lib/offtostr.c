#define inttostr offtostr
#define inttype off_t
#include "inttostr.c"
