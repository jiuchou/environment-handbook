#include "diffcount.h"

static void process_diff_common_lines(lin, lin);
static void process_diff_hunk(struct change *);

/* Next line number to be printed in the two input files.  */
static lin next0, next1;

/* Print the edit-script SCRIPT as a sdiff style output.  */
void process_diff_script(struct change *script) {
  next0 = next1 = -files[0].prefix_lines;
  process_script(script, find_change, process_diff_hunk);
  process_diff_common_lines(files[0].valid_lines, files[1].valid_lines);
}

/* diff的结果在一个非0结尾的字符数组中
  \把首尾的制表符和空格全部去掉
  新的长度通过len传出
*/
static char *strip_white_in_array(char *array, int *len) {
  int i = 0;
  int array_len = *len;
  char *array_pointer = array;
  if (array_len == 0)
    return 0;
  /* Strip 开头掉所有的制表符 */
  while ((i < array_len) &&
       ((array[i] == ' ') || (array[i] == '\n') || (array[i] == '\r') || (array[i] == '\t')))
  {
    i++;
    array_pointer++;
  }
  if (i < array_len)
  {
    array_len = array_len - i;
  }
  else
  {
    /* 发现是空行 */
    *len = 0;
    return 0;
  }
  /* strip 掉结尾的制表符 */
  i = array_len - 1;
  while ((i >= 0) &&
       ((array_pointer[i] == ' ') || (array_pointer[i] == '\n') || (array_pointer[i] == '\r') || (array_pointer[i] == '\t')))
  {
    i--;
  }
  if (i < 0)
  {
    *len = 0;
    return 0;
  }
  else
  {
    array_len = i + 1;
  }
  *len = array_len;
  return array_pointer;
}

/* 把diff结果中的字符串(被字符串符号框住的)去掉,避免字符串框住注释符的影响*/
void get_strip_string_from_array(char *strip_array, char *array, int *len, char *string_symbol)
{
	int i = 0;
	char *strip_pointer = strip_array;
	char *array_pointer = array;
	int strip_len = 0;
	int array_len = *len;
	char symbol = *string_symbol;
	int string_process = 0;
	while (i < array_len)
	{
		if ((*array_pointer != symbol) && (!string_process))
		{
			*strip_pointer = *array_pointer;
			strip_pointer++;
			strip_len++;
		}
		else if (*array_pointer == symbol)
		{
			string_process = !string_process;
		}
		i++;
		array_pointer++;
	}
	*len = strip_len;
}
static void add_node_to_diffed_list(enum changes line_status, enum line_comment_type line_comment)
{
	struct diffed_line_node *link = (struct diffed_line_node *)malloc(sizeof(struct diffed_line_node));
	link->next = NULL;
	link->line_comment = line_comment;
	link->line_status = line_status;
	if (line_node_head == NULL)
	{
		line_node_head = line_node_tail = link;
	}
	else
	{
		line_node_tail->next = link;
		line_node_tail = link;
	}
}
/* Debug print Add list processing....... */
static void print_debug_line(enum changes line_status, enum line_comment_type line_comment,
							 char *string, int length)
{
	char *ppp = string;
	int len = length;
	char sep[20];
	switch (line_status)
	{
	case CHANGED:
		strcpy(sep, " [|]");
		break;
	case OLD:
		strcpy(sep, " [-]");
		break;
	case NEW:
		strcpy(sep, " [+]");
		break;
	case UNCHANGED:
		strcpy(sep, " [@]");
		break;
	defaut:
		break;
	}
	switch (line_comment)
	{
	case BlockCommentOn:
		strcat(sep, "[BlockCommentOn] ");
		break;
	case BlockCommentOff:
		strcat(sep, "[BlockCommentOff] ");
		break;
	case LineComment:
		strcat(sep, "[LineComment] ");
		break;
	case NormalLine:
		strcat(sep, "[NormalLine] ");
		break;
	case BlankLine:
		strcat(sep, "[BlankLine ] ");
		break;
	case NormalWithComment:
		strcat(sep, "[NormalWithComment] ");
		break;
	case NormalWithBlockOn:
		strcat(sep, "[NormalWithBlockOn] ");
		break;
	case BlockOffWithNormal:
		strcat(sep, "[BlockOffWithNormal] ");
		break;
	default:
		break;
	}
	printf("%s", sep);
	while (ppp < string + len)
	{
		register unsigned char c = *ppp++;
		printf("%c", c);
	}
	printf("\n");
}

/* construct diff list from diff result 
   (counting process read this list and do analyzing )
*/
static void construct_diffed_list(enum changes line_status, char const *const *line)
{
	register char const *text_pointer = line[0];
	register char const *text_limit = line[1];
	char *trim_array;
	char *trim_string_array;
	char *free_array_pointer = 0;
	int text_length = text_limit - text_pointer;
	int trim_text_length;
	int found_pattern = -1;
	char *line_comment_string = current_language->line_comment;
	char *block_commenton_string = current_language->block_comment_on;
	char *block_commentoff_string = current_language->block_comment_off;
	char *block_commenton_alt_string = current_language->block_comment_on_alt;
	char *block_commentoff_alt_string = current_language->block_comment_off_alt;
	/*add string symbol for exclude some comment symbol */
	char *string_symbol = current_language->string_symbol;
	int block_comment_len = strlen(block_commentoff_string);
	int block_comment_alt_len = strlen(block_commentoff_alt_string);
	int line_comment_result, block_commenton_result, block_commentoff_result,
		block_commenton_alt_result, block_commentoff_alt_result,
		string_symbol_result;
	enum line_comment_type final_finding_comment_mode;
	if (line)
	{
		trim_array = strip_white_in_array(text_pointer, &text_length);
		trim_text_length = text_length;
		if (trim_array)
		{
			/*如果有字符串，对字符串进行剔除*/
			string_symbol_result = find_string_in_array(trim_array, string_symbol, text_length);
			if (string_symbol_result != -1)
			{
				free_array_pointer = trim_string_array = (char *)xmalloc(text_length);
				get_strip_string_from_array(trim_string_array, trim_array, &trim_text_length, string_symbol);
			}
			else
			{
				trim_string_array = trim_array;
			}
			/*在剔除后的字符串中匹配各种注释符号*/
			line_comment_result = find_string_in_array(trim_string_array, line_comment_string, trim_text_length);
			block_commenton_result = find_string_in_array(trim_string_array, block_commenton_string, trim_text_length);
			block_commentoff_result = find_string_in_array(trim_string_array, block_commentoff_string, trim_text_length);
			block_commenton_alt_result = find_string_in_array(trim_string_array, block_commenton_alt_string, trim_text_length);
			block_commentoff_alt_result = find_string_in_array(trim_string_array, block_commentoff_alt_string, trim_text_length);

			/* 没有任何注释符号的，判断为一个正常行
			  notes: 所谓正常行可能是代码行，也可能是块注释的内容*/
			if ((line_comment_result == -1) && (block_commenton_result == -1) && (block_commentoff_result == -1) && (block_commenton_alt_result == -1) && (block_commentoff_alt_result == -1))
				final_finding_comment_mode = NormalLine;
			else
				/* 以行注释符号打头的，本行判断为注释 */
				if (line_comment_result == 0)
				final_finding_comment_mode = LineComment;
			else
				/* 存在行注释符号，且不起头,并且没有其他注释符号的*/
				if ((line_comment_result > 0) && (block_commenton_result == -1) && (block_commentoff_result == -1) && (block_commenton_alt_result == -1) && (block_commentoff_alt_result == -1))
				final_finding_comment_mode = NormalWithComment;
			else
				/* 以块注释开始符打头，并且没有块注释结束，判断为注释开始*/
				if ((block_commenton_result == 0) && (block_commentoff_result == -1))
				final_finding_comment_mode = BlockCommentOn;
			else
				/* 以可选块注释开始符打头，并且没有可选块注释结束，判断为注释开始*/
				if ((block_commenton_alt_result == 0) && (block_commentoff_alt_result == -1))
				final_finding_comment_mode = BlockCommentOn;
			else
				/*存在块注释符号开始后，并不打头，而且没有块注释符号结束，判定为NormalWithBlockOn*/
				if ((block_commenton_result > 0) && (block_commentoff_result == -1))
				final_finding_comment_mode = NormalWithBlockOn;
			else
				/*存在可选块注释符号开始后，并不打头，而且没有可选块注释符号结束，判定为NormalWithBlockOn*/
				if ((block_commenton_alt_result > 0) && (block_commentoff_alt_result == -1))
				final_finding_comment_mode = NormalWithBlockOn;
			else
				/* 存在块注释结束符号，并且不存在块注释开始符号的情况	*/
				if ((block_commenton_result == -1) && (block_commentoff_result != -1))
			{
				/*如果之后还有内容*/
				if ((text_length - block_commentoff_result) > block_comment_len)
					final_finding_comment_mode = BlockOffWithNormal;
				else
					final_finding_comment_mode = BlockCommentOff;
			}

			else
				/* 存在可选块注释结束符号，并且不存在可选块注释开始符号的情况*/
				if ((block_commenton_alt_result == -1) && (block_commentoff_alt_result != -1))
			{
				/*如果之后还有内容*/
				if ((text_length - block_commentoff_alt_result) > block_comment_alt_len)
					final_finding_comment_mode = BlockOffWithNormal;
				else
					final_finding_comment_mode = BlockCommentOff;
			}			else
				/*同时存在块注释开始和块注释结束的情况*/
				if ((block_commenton_result != -1) && (block_commentoff_result != -1))
			{
				/*以块注释起始打头，且以快注释结束为结束的，认定为行注释*/
				if ((block_commenton_result == 0) &&
					((text_length - block_commentoff_result) == block_comment_len))
					final_finding_comment_mode = LineComment;
				else
					/*块注释起始不在最前边的，且注释开始在注释结束之前
    				  标识为NormalWithComment*/
					if (block_commenton_result < block_commentoff_result)
					final_finding_comment_mode = NormalWithComment;
				/* 如果块开始注释符还在块结束注释符后边，则情况比较复杂:
				   1. aaaaaaaaaa *)  (* bbbb
				   2. aaaaaaaaaa*) (* bbbbbbb *)
				   3. aaaaaaaaaa*) (* bbbbbbb *) kkkkkkkk....
				   但肯定是一个块注释的结束，目前先简化处理，后续用正则表达式专门处理
				*/
				else
					final_finding_comment_mode = BlockCommentOff;
			}

			else
				/*同时存在可选块注释开始和可选块注释结束的情况*/
				if ((block_commenton_alt_result != -1) && (block_commentoff_alt_result != -1))
			{
				/*以块注释起始打头，且以快注释结束为结束的，认定为行注释*/
				if ((block_commenton_alt_result == 0) &&
					((text_length - block_commentoff_alt_result) == block_comment_alt_len))
					final_finding_comment_mode = LineComment;
				else if (block_commenton_alt_result < block_commentoff_alt_result)
					final_finding_comment_mode = NormalWithComment;
				else
					final_finding_comment_mode = BlockCommentOff;
			}
			/*整理最后的结果，加入线性表*/
			add_node_to_diffed_list(line_status, final_finding_comment_mode);
			if (print_lines_info)
				/* Debug print the add list processing... */
				print_debug_line(line_status, final_finding_comment_mode, trim_array, text_length);
			/* free xalloc space */
			if (free_array_pointer)
				free(free_array_pointer);
		}
		else
		{
			/* all are blanks ,add blank line to list*/
			final_finding_comment_mode = BlankLine;
			add_node_to_diffed_list(line_status, final_finding_comment_mode);
			if (print_lines_info)
				/* Debug print the add list processing... */
				print_debug_line(line_status, final_finding_comment_mode, "", 0);
		}
	}
}
/* process lines common to both files in side-by-side format.  */
static void process_diff_common_lines(lin limit0, lin limit1)
{
	lin i0 = next0, i1 = next1;
	if (i0 != limit0 || i1 != limit1)
	{
		while (i0 != limit0 && i1 != limit1)
		{
			construct_diffed_list(UNCHANGED, &files[1].linbuf[i1]);
			i0++;
			i1++;
		}
	}
	next0 = limit0;
	next1 = limit1;
}

/* process a hunk of an sdiff diff.
   This is a contiguous portion of a complete edit script,
   describing changes in consecutive lines.  */
static void process_diff_hunk(struct change *hunk)
{
	lin first0, last0, first1, last1;
	register lin i, j;
	/* Determine range of line numbers involved in each file.  */
	enum changes changes =
		analyze_hunk(hunk, &first0, &last0, &first1, &last1);
	if (!changes)
		return;
	/* Print out lines up to this change.  */
	process_diff_common_lines(first0, first1);
	/*``xxx  |  xxx '' lines */
	if (changes == CHANGED)
	{
		for (i = first0, j = first1; i <= last0 && j <= last1; i++, j++)
		{
			construct_diffed_list(CHANGED, &files[1].linbuf[j]);
		}
		changes = (i <= last0 ? OLD : 0) + (j <= last1 ? NEW : 0);
		next0 = first0 = i;
		next1 = first1 = j;
	}
	/*  ``     >  xxx '' lines */
	if (changes & NEW)
	{
		for (j = first1; j <= last1; ++j)
		{
			construct_diffed_list(NEW, &files[1].linbuf[j]);
		}
		next1 = j;
	}
	/*  ``xxx  <     '' lines */
	if (changes & OLD)
	{
		for (i = first0; i <= last0; ++i)
		{
			construct_diffed_list(OLD, &files[0].linbuf[i]);
		}
		next0 = i;
	}
}
