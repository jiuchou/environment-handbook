#include "version.h"

/*
char const copyright_string[] =
    "\n\tHikSvnCount\n\
\tWritten by Haiyuan.Qian\n\
\tDIFF part inherits from GNU Diff Utilities\n\
\tCopyright (C) RDMG @ Hikvision 2013\n";

char const version_string[] = "Version 1.0.2";
*/

// UpdateTime: 2019.02.20
void get_version()
{
    char const copyright_string[] =
        "\n\tHikSvnCount\n\
\tWritten by Haiyuan.Qian\n\
\tDIFF part inherits from GNU Diff Utilities\n\
\tCopyright (C) RDMG @ Hikvision 2013\n";
    char const version_string[] = "Version 1.1.0";

    printf("\n\tDiffcount Utility  %s\n%s\n", version_string, copyright_string);
}

void getVersion(){
    char const copyright_string[] = 
        "\n\tsvn_version_diff_count\n\
\tWritten by jiuchou\n\
\tDIFF part inherits from GNU Diff Utilities\n\
\tCopyright (C) 2019 jiuchou\n";
    char const version_string[] = "Version 1.1.0";

    printf("\n\tDiffcount Utility  %s\n%s\n", version_string, copyright_string);
}
