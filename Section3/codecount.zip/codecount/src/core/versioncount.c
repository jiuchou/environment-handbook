#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <diffcount.h>
#include <getopt.h>

static int achieveCommand(char **buf, char *command)
{
    FILE *fp = NULL;
    fp = popen(command, "r");
    if (fp == NULL) {
        pclose(fp);
        return EXIT_FAILURE;
    }
    *buf = (char *)malloc(4096);
    memset(*buf, 0, 4096);
    int bufsize = 4096;
    int len = 0;
    while(fgets(*buf + len, bufsize - len, fp) != NULL){
        len = strlen(*buf);
        if (len >= bufsize - 1) {
            bufsize *= 2;
            *buf = (char *)realloc(*buf, bufsize);
        }
    }
    pclose(fp);
    return EXIT_SUCCESS;
}

static int getLine(char **buffer, char **lineStr)
{
    char *lpstop = NULL;

    if (*buffer == NULL)
        return EXIT_FAILURE;
    lpstop = strstr(*buffer, "\n");
    if (NULL != lpstop)
    {
        *lineStr = *buffer;
        *buffer = lpstop + 1;
        *lpstop = '\0';
    }
    else
    {
        *lineStr = *buffer;
        *buffer = NULL;
    }
    return EXIT_SUCCESS;
}

static void printDiffResult(char *left, char *right,
                            struct diffcount_result *result,
                            int lang_number, float total_standard_c_nbnc_lines) {
    printf("-------------------------------------------------------------\n");
    printf("LANG\tADD\tMOD\tDEL\tA&M\tBLK\tCMT\tNBNC\n");
    printf("-------------------------------------------------------------\n");

    for (int i = 0; i < lang_number; i++)
    {
        printf("%s", result[i].language_name);
        printf("\t%d", result[i].total_added_lines);
        printf("\t%d", result[i].total_modified_lines);
        printf("\t%d", result[i].total_deleted_lines);
        printf("\t%d", result[i].total_added_lines + result[i].total_modified_lines);
        printf("\t%d", result[i].changed_blank_lines);
        printf("\t%d", result[i].changed_comment_lines);
        printf("\t%d", result[i].changed_nbnc_lines);
        printf("\t%.2f\n", result[i].standard_c_rate);
    }
    printf("-------------------------------------------------------------\n");
}
static void rand_str(int in_len, char *OutStr) {
    char Str[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    int len = strlen(Str);
    memset(OutStr, 0, strlen(OutStr));
    srand((unsigned int)time(NULL) + rand()); //初始化随机数的种子
    int i = 0;
    for (; i < in_len; i++)
    {
        OutStr[i] = Str[rand() % len];
    }
    OutStr[i] = '\0';
}
static char const shortopts[] = "hqv";
/* Values for long options that do not have single-letter equivalents.  */
/* -- 对于只有长参数的参数解析，在这里添加映射关系 ----*/
enum {
    HELP_OPTION = CHAR_MAX + 1,
    SUPPORT_LANGS_OPTION,
    SVN_REVISION_START_OPTION,
    SVN_REVISION_END_OPTION
};
static struct option const longopts[] = {
    {"version-start", required_argument, 0, SVN_REVISION_START_OPTION},
    {"version-end", required_argument, 0, SVN_REVISION_END_OPTION},
    {"help", no_argument, 0, 'h'},
    {"help-zh_cn", no_argument, 0, HELP_OPTION},
    {"quiet", no_argument, 0, 'q'},
    {"support-langs", no_argument, 0, SUPPORT_LANGS_OPTION},
    {"version", no_argument, 0, 'v'},
    /* end flag */
    {0, 0, 0, 0}
};
static void checkStdout(void) {
    if (ferror(stdout))
        fatal("write failed");
    else if (fclose(stdout) != 0)
        pfatal_with_name(_("standard output"));
}
static void printSupportLangs() {
    int i = 0;
    printf("Diffcount support languages list below:\n");
    printf("LANG\t\tLCMT\tBCMT1S\tBCMT1E\tBCMT2S\tBCMT2E\tSTRSB\tEXTS\t\t\t\tRATE\n");
    while (languages[i].id != -1)
    {
        printf("%s", languages[i].language_name);
        printf("\t\t%s", languages[i].line_comment);
        printf("\t%s", languages[i].block_comment_on);
        printf("\t%s", languages[i].block_comment_off);
        printf("\t%s", languages[i].block_comment_on_alt);
        printf("\t%s", languages[i].block_comment_off_alt);
        printf("\t%s", languages[i].string_symbol);
        printf("\t%s", languages[i].file_extensions);
        printf("\t\t\t\t%.2f\n", languages[i].standard_c_rate);
        i++;
    }
}
static char const *const option_help_msgid[] = {
    N_("Compare and diff two packages or only couting one code package"),
    "",
    N_("OPTIONS:"),
    N_("  --svn-url"),
    N_("      svn url path"),
    N_("  --version-start"),
    N_("      revision starting"),
    N_("  --version-end"),
    N_("      revision ending"),
    N_("  --quiet"),
    N_("      Less verbose output"),
    N_("  --support-langs"),
    N_("      Show supported languages list"),
    N_("  -v  --version"),
    N_("      Output current version."),
    N_("  -h/--help"),
    N_("      Show this page"),
    N_("  --help-zh_cn"),
    N_("      Show Chinese help page"),
    "",
    N_("Report bugs to <jiuchou@example.com>."),
    0
};
//中文的帮助说明
static char const *const option_help_msgid_cn[] = {
    N_("功能：对两个代码包/文件进行差异统计、或者对一个代码包/文件进行代码行统计"),
    "",
    N_("参数说明:"),
    N_("  --svn-url"),
    N_("      SVN URL地址"),
    N_("  --version-start"),
    N_("      开始版本"),
    N_("  --version-end"),
    N_("      结束版本"),
    N_("  --quiet"),
    N_("      静默日志数输出"),
    N_("      Tips: 如果文件较多的话，日志打印的时间会很长，如果需要，可关闭日志"),
    N_("  --support-langs"),
    N_("      输出支持的编程语言列表"),
    N_("  -v/--version"),
    N_("      输出当前的版本信息"),
    N_("  -h/--help"),
    N_("      输出缺省帮助信息"),
    N_("  --help-zh_cn"),
    N_("      输出中文帮助信息"),
    N_("  --langs"),
    N_("关于代码行的说明:"),
    N_("  本程序的有效代码行使用\"非空非注释行\"(NBNC)的概念"),
    N_("  最后进行代码行折算的时候,只使用NBNC行数"),
    "",
    N_("Support:"),
    N_("  Report bugs to <jiuchou@example.com>"),
    0
};
static void usage(char *option) {
    char const *const *p;
    if (option == "") {
        printf(_("\nUsage: %s [OPTION]... svnUrl\n\n"), programName);
        /* code */
        p = option_help_msgid;
    } else if (option == "zh_cn") {
        printf(_("\n使用方法: %s [参数选项]... SVN路径\n\n"), programName);
        p = option_help_msgid_cn;
        /* code */
    }
    for (; *p; p++)
    {
        if (!**p)
            putchar('\n');
        else
        {
            char const *msg = _(*p);
            char const *nl;
            while ((nl = strchr(msg, '\n')))
            {
                int msglen = nl + 1 - msg;
                printf("  %.*s", msglen, msg);
                msg = nl + 1;
            }
            printf("  %s\n" + 2 * (*msg != ' ' && *msg != '-'), msg);
        }
    }
}
/*----DIFF COUNT HELP---------------*/
static void printHelp(char const *reason_msgid, char const *operand) {
    if (reason_msgid) {
        error(0, 0, _(reason_msgid), operand);
    }
    error(EXIT_TROUBLE, 0, _("Try `%s --help or --help-zh_cn' for more information."), programName);
    abort();
}
int countVersionDiff(char *svnUrl, int revisionStart, int revisionEnd) {
    int status = EXIT_SUCCESS;
    // svn diff http://10.6.5.2/svn/conf/CMCode/CoverityTools --summarize -r 650:HEAD
    char svnCmd[1024] = {0};
    char *diffBuf = NULL;
    sprintf(svnCmd, "svn diff \"%s\" --summarize -r %d:%d", svnUrl, revisionStart, revisionEnd);
    achieveCommand(&diffBuf, svnCmd);
    if (!lessVerboseOutput) {
        printf("%s\n", svnCmd);
        printf(" jiuchou: svnUrl   %s\n", svnUrl);
    }
    char *pathLeft = (char *)malloc(256);
    memset(pathLeft, 0, 256);
    char *pathRight = (char *)malloc(256);
    memset(pathRight, 0, 256);
    struct diffcount_result *result;
    int lang_number = 0;
    float total_standard_c_nbnc_lines = 0;
    /**
     * 1. 判断是否存在差异，如果不存在，不进行处理
     * 2. 判断差异内容，是否符合判断条件(通过svn diff查看到的差异信息格式为"D       svnUrl/filename")
     *      注意：svnlook changed查看到的差异信息格式为"D   svnId/filename"
     *      示例：
     *          1) svnlook changed
     *              U   svn/jiuchou/test.c
     *          2) svn diff
     *              M   svn_url/jiuchou/test.c
     * 3. 判断是否统计语言，如果不统计，不进行处理
     * 
     * 4. 判断变更类型
     * 
     * 5. 定义新老文件临时文件名称
     * 
     * 6. 
     */
    char *lprightstr = diffBuf;
    char *lplinestr = NULL;
    while(getLine(&lprightstr, &lplinestr) == EXIT_SUCCESS){
        int change_type = 0;
        if (NULL == lplinestr)
        {
            break;
        }
        if (strlen(lplinestr) <= 8 || strlen(lplinestr) > 512)
        {
            continue;
        }
        /* 语言识别*/
        if (!(current_language = get_current_language(lplinestr)))
        {
            continue;
        }
        switch (*lplinestr) {
            case 'A':
                change_type = ADD;
                break;
            case 'D':
                change_type = DEL;
                break;
            case 'M':
                change_type = MOD;
                break;
            default:
                break;
        }
        if (!lessVerboseOutput) {
            printf("\ncurrent_language is %s\n", current_language->language_name);
            printf("change_type is %d!\n", change_type);
        }
        svn_info.svn_url_path = lplinestr + 8;
        // 获取当前文件扩展名，用于临时文件后缀定义
        char *filename_ex = svn_info.svn_url_path + strlen(svn_info.svn_url_path);
        while(*filename_ex != '/' && filename_ex >= svn_info.svn_url_path){
            filename_ex--;
        }
        filename_ex++;
        if (!lessVerboseOutput) {
            printf(" jiuchou: svn_info.svn_url_path %s\n", svn_info.svn_url_path);
        }
        char str_rand[9] = {0};
        rand_str(8, str_rand);
        sprintf(pathRight, "/tmp/new_%s%s", str_rand, filename_ex);
        sprintf(pathLeft, "/tmp/old_%s%s", str_rand, filename_ex);
        if (change_type == ADD || change_type == MOD) {
            sprintf(svnCmd, "svn cat -r %d \"%s\" > \"%s\"", revisionEnd, svn_info.svn_url_path, pathRight);
            system(svnCmd);
            if (!lessVerboseOutput) {
                printf(svnCmd);
                printf("\n");
            }
        }
        if (change_type == ADD) {
            status = compare_files((struct comparison *)0, "", pathRight);
            remove(pathRight);
        }
        else if (change_type == DEL) {
            char *lineBuf = NULL;
            sprintf(svnCmd, "svn cat -r %d %s@%d | wc -l", revisionStart, svn_info.svn_url_path, revisionStart);
            if (achieveCommand(&lineBuf, svnCmd) == EXIT_FAILURE)
            {
                //发生错误
                continue;
            }
            current_language->total_deleted_lines += atoi(lineBuf);
            if (!lessVerboseOutput) {
                printf(svnCmd);
                printf("\n");
                printf("%s", current_language->language_name);
                printf("\t%d", 0);
                printf("\t%d", 0);
                printf("\t%d", atoi(lineBuf));
                printf("\t%d", 0);
                printf("\t%d", 0);
                printf("\t%d", 0);
                printf("\t%d", 0);
                printf("\t%s", "DEL");
                printf("\t%s", svn_info.svn_url_path);
                printf("\t%s\n", "");
            }
            free(lineBuf);
            lineBuf = NULL;
        }
        else if (change_type == MOD) {
            sprintf(svnCmd, "svn cat -r %d \"%s\" > \"%s\"", revisionStart, svn_info.svn_url_path, pathLeft);
            system(svnCmd);
            if (!lessVerboseOutput) {
                printf(svnCmd);
                printf("\n");
            }
            status = diffcount_compare_packages(pathLeft, pathRight);
            remove(pathLeft);
            remove(pathRight);
        }
    }
    diffcount_establish_result(&result, &lang_number, &total_standard_c_nbnc_lines);
    printDiffResult(pathLeft, pathRight, result, lang_number, total_standard_c_nbnc_lines);
    free(result);
    free(pathLeft);
    free(pathRight);
    free(diffBuf);
    return status;
}
int main(int argc, char const *argv[]) {
    int status = EXIT_SUCCESS;
    // int revisionStart = revision - 1;
    // int revisionEnd = revisionEnd;
    int revisionStart = 0;
    int revisionEnd = 0;
    /* Program name ---> 'versiondiffcount' */
    programName = argv[0];
    initParameters();
    /**
     * Decode the options.
     */
    int c;
    while ((c = getopt_long(argc, argv, shortopts, longopts, 0)) != -1)
    {
        switch (c)
        {
            case SVN_REVISION_START_OPTION:
                if (optarg && strlen(optarg) < 12 && strlen(optarg) >= 1) {
                    revisionStart = atoi(optarg);
                } else {
                    usage("");
                    checkStdout();
                    return EXIT_SUCCESS;
                }
                trace2("Get Option: revisionStart \n");
                break;
            case SVN_REVISION_END_OPTION:
                if (optarg && strlen(optarg) < 12 && strlen(optarg) >= 1) {
                    revisionEnd = atoi(optarg);
                } else {
                    usage("");
                    checkStdout();
                    return EXIT_SUCCESS;
                }
                trace2("Get Option: revisionEnd \n");
                break;
            case 'q':
                lessVerboseOutput = true;
                break;
            case 'v':
                getVersion();
                checkStdout();
                return EXIT_SUCCESS;
            case SUPPORT_LANGS_OPTION:
                printSupportLangs();
                checkStdout();
                return EXIT_SUCCESS;
            case 'h':
                usage("");
                checkStdout();
                return EXIT_SUCCESS;
            case HELP_OPTION:
                usage("zh_cn");
                checkStdout();
                return EXIT_SUCCESS;
            default:
                printHelp(0, 0);
        }
    }
    if ((argc - optind) != 1) {
        printf("Error: The value of argc must be 1 larger than that of optind, ");
        printf("but difference value is %d\n", (argc - optind));
        return EXIT_FAILURE;
    }
    /**
        printf("argc - optind: %d\n", argc - optind);
        printf("name argument: %d\n", argc);
        printf("name argument: %d\n", optind);
        printf("name argument: %s\n", argv[optind]);
        printf("name argument: %s\n", svnUrl);
     */
    char *svnUrl=argv[optind];
    status = countVersionDiff(svnUrl, revisionStart, revisionEnd);
    return status;
}
