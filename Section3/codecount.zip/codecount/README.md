# CodeCount

CodeCount基于开源diffcount（C.YANG. 2006）和 开源[svncount](https://code.csdn.net/qhy218/svncount)（Haiyuan.Qian 2014），实现能力包括：

- 文件/目录代码量统计
- 两个文件/目录差异代码量统计
- SVN提交 `post commit` 代码行统计（增、删、改）

新增能力包括：

- SVN任意版本差异代码量统计（增、删、改）

计划实现能力包括：

- Git提交代码行统计（增、删、改）
- Git任意版本差异代码量统计（增、删、改）

> **关于代码行的说明**
>
> 1. 本程序的有效代码行使用"非空非注释行"(NBNC)的概念
> 2. 最后进行代码行折算的时候,只使用NBNC行数

## 开发

```bash
# 克隆项目
git clone https://github.com/jiuchou/codecount.git
```

## 发布

编译`diffcount`工具

```bash
make
```

编译`SVN任意版本差异代码量统计`工具

```bash
make version
```

## 在线手册

- **使用方法**

  ```bash
  diffcount [参数选项]... (基线代码包/文件) 目标代码包/文件
  ```

- **[参数说明](docs/parameters.md)**

## 目录结构

初始的目录结构如下：

```
docs/
include/
lib/
Makefile
README.en.md
README.md
src/
```

## 类似工具

> 本工具具备统计修改差异量，业界代码统计工具一般只具备增加、删除差异量。
>
> 拓展 [代码统计工具实测点评](https://www.cnblogs.com/jenly/p/5941069.html)

- cloc/sloc
- SourceCounter
- GitStats
- Gnuplot
- CodeMetric
- ICodeStat
- StatSVN

## 版权信息

CodeCount遵循Apache2开源协议发布，并提供免费使用。

本项目包含的第三方源码和二进制文件之版权信息另行标注。

版权所有Copyright © 2018-2020 by jiuchou(315675275@qq.com)

All rights reserved。

CodeCount® 商标和著作权所有者为 `jiuchou`。

更多细节参阅 [LICENSE](LICENSE)

## **技术支持**

*jiuchou <315675275@qq.com>*