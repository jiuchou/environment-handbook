备注：mysql数据库的设计中包含了repos_id, user_id等信息，本代码并不包含该部分实现及维护过程。

1.repos_id是版本库ID，一般为Repos表的一个ID字段，如果没有，也可以改为char，直接写入repos名称
2.revision svn的版本号
3.path svn库内的相对路径
4.user_id 账户ID，为User表的ID字段，如果没有，也可以改为char，直接写入User名称
5.date 修改日期
6.diff_state 文件差异状态，一般为新增，删除，修改
7.added_lines 添加的loc
8.modified_lines 修改的loc
9.deleted_lines 删除的loc
10.changed_blank_lines 空白行
11.changed_comment_lines 注释行
12.changed_nbnc_lines 非空非注释行，即有效代码行
13.language_type 编程语言
14.commit_level 提交等级，用于区分代码导入等情况

--代码统计表
CREATE TABLE `code_count` (
  `id` bigint(16) NOT NULL AUTO_INCREMENT,
  `repos_id` varchar(256) NOT NULL,
  `revision` int(11) NOT NULL,
  `path` varchar(1024) NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `date` date NOT NULL,
  `diff_state` enum('DEL','NEW','MOD') character set latin1 NOT NULL,
  `added_lines` int(11) default '0',
  `modified_lines` int(11) default '0',
  `deleted_lines` int(11) default '0',
  `changed_blank_lines` int(11) default '0',
  `changed_comment_lines` int(11) default '0',
  `changed_nbnc_lines` int(11) default '0',
  `language_type` varchar(32) default NULL,
  `commit_desp` tinytext default '',
  `commit_level` enum('Replace','ImportII','ImportI','Warning','Normal') NOT NULL default 'Normal' COMMENT '提交等级，Normal为正常，ImportI可能是代码导入，ImportII是大批量代码导入，Replace为特殊的分支文件替换，Warning为存在警告的文件',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX `INDEX_USER_ID` ON `code_count`(`user_id`);
CREATE INDEX `INDEX_DATE` ON `code_count`(`date`);

--员工代码提交记录报表
CREATE TABLE `rp_staff_code_count` (
  `interval_id` bigint(16) NOT NULL AUTO_INCREMENT, 
  `user_id` varchar(64) NOT NULL,
  `statdate` date NOT NULL,
  `start_revision` int(11) NOT NULL,
  `end_revision` int(11) NOT NULL,
  `added_lines` int(11) default '0',
  `modified_lines` int(11) default '0',
  `deleted_lines` int(11) default '0',
  `changed_blank_lines` int(11) default '0',
  `changed_comment_lines` int(11) default '0',
  `changed_nbnc_lines` int(11) default '0',
  `week` int(11) NOT NULL,
  `user_name` char(30),
  PRIMARY KEY  (`interval_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX `INDEX_USER_ID` ON `rp_staff_code_count`(`user_id`);
CREATE INDEX `INDEX_STAT_DATE` ON `rp_staff_code_count`(`statdate`);

--模块代码提交记录报表
CREATE TABLE `rp_repos_code_count` (
  `interval_id` bigint(16) NOT NULL AUTO_INCREMENT, 
  `repos_id` varchar(256) NOT NULL,
  `statdate` date NOT NULL,
  `start_revision` int(11) NOT NULL,
  `end_revision` int(11) NOT NULL,
  `added_lines` int(11) default '0',
  `modified_lines` int(11) default '0',
  `deleted_lines` int(11) default '0',
  `changed_blank_lines` int(11) default '0',
  `changed_comment_lines` int(11) default '0',
  `changed_nbnc_lines` int(11) default '0',
  `repos_path` VARCHAR(1024),
  `repos_name` VARCHAR(128),
  `is_trunk` tinyint(1) default 1,
  `week` int(11) NOT NULL,
  `main_repos` varchar(128),
  PRIMARY KEY  (`interval_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE INDEX `INDEX_STAT_DATE` ON `rp_repos_code_count`(`statdate`);

--版本模块库维护表
CREATE  TABLE `repos_info` (
  `id` BIGINT(16) NOT NULL ,
  `repos_id` VARCHAR(256) NOT NULL,
  `repos_name` VARCHAR(128) NOT NULL,
  PRIMARY KEY (`id`) 
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

--员工代码统计存储过程
DROP PROCEDURE IF EXISTS `P_COUNT_STAFF_CODE`;
DELIMITER $$
CREATE PROCEDURE `P_COUNT_STAFF_CODE`() 

begin 
	declare added_lines int(11);
	declare modified_lines int(11);
	declare deleted_lines int(11);
	declare changed_blank_lines int(11);
	declare changed_comment_lines int(11);
	declare changed_nbnc_lines int(11);
	declare user_id varchar(64);
	declare statdate date;
	declare start_revision int(11);
	declare end_revision int(11);
	declare user_name char(30);
	DECLARE done int default 0;
	
	declare cur_flow cursor for 
	select sum(t.added_lines) as added_lines, 
		   sum(t.modified_lines) as modified_lines,
           sum(t.deleted_lines)as deleted_lines,
           sum(t.changed_blank_lines) as changed_blank_lines, 
           sum(t.changed_comment_lines) as changed_comment_lines,
           sum(t.changed_nbnc_lines) as changed_nbnc_lines,
           t.user_id as user_id,
           date(now()) as statdate,
		   max(t.revision) as end_revision,
		   min(t.revision) as start_revision,
		   u.realname
    from code_count t,zentao.zt_user u
    where TO_DAYS(now()) - TO_DAYS(t.date) <= 1 and u.number = t.user_id group by t.user_id; 
	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done=1;
	open cur_flow;	
	fetch cur_flow into added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,user_id,statdate,end_revision,start_revision,user_name;
	
	while done <> 1 do
	insert into rp_staff_code_count(added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,user_id,statdate,end_revision,start_revision,week,user_name) 
		values(added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,user_id,statdate,end_revision,start_revision,week(statdate),user_name); 
	commit;
	fetch cur_flow into added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,user_id,statdate,end_revision,start_revision,user_name;
    end while;			
	close cur_flow;
end
$$
DELIMITER ;

--模块代码统计存储过程
DROP PROCEDURE IF EXISTS `P_COUNT_REPOS_CODE`;
DELIMITER $$
CREATE PROCEDURE `P_COUNT_REPOS_CODE`() 

begin 
	declare added_lines int(11);
	declare modified_lines int(11);
	declare deleted_lines int(11);
	declare changed_blank_lines int(11);
	declare changed_comment_lines int(11);
	declare changed_nbnc_lines int(11);
	declare repos_id varchar(256);
	declare statdate date;
	declare start_revision int(11);
	declare end_revision int(11);
	declare repos_path varchar(256);
	declare repos_name varchar(128);
	declare main_repos varchar(128);
	declare done int default 0;
	declare cur_1 cursor for select s.repos_id, s.repos_name from repos_info s;
	
	declare cur_2 cursor for 
	select 
       sum(t.added_lines), 
	   sum(t.modified_lines),
	   sum(t.deleted_lines),
	   sum(t.changed_blank_lines), 
	   sum(t.changed_comment_lines),
	   sum(t.changed_nbnc_lines),
	   substring_index(substring(t.path, LENGTH(concat(repos_id,'Branches/')) + 1),'/',1),
	   date(now()),
	   max(t.revision) as end_revision,
	   min(t.revision) as start_revision,
	   t.repos_id as main_repos
	from code_count t 
	where LOCATE(concat(repos_id,'Branches/'), t.path) <> 0 and TO_DAYS(now()) - TO_DAYS(t.date) <= 1
	group by substring_index(substring(t.path, LENGTH(concat(repos_id,'Branches/')) + 1),'/',1); 
	
	declare cur_3 cursor for 
	select 
       sum(t.added_lines), 
	   sum(t.modified_lines),
	   sum(t.deleted_lines),
	   sum(t.changed_blank_lines), 
	   sum(t.changed_comment_lines),
	   sum(t.changed_nbnc_lines),
	   concat(repos_id,'Trunk/'),
	   date(now()),
	   max(t.revision) as end_revision,
	   min(t.revision) as start_revision,
	   t.repos_id as main_repos
	from code_count t 
	where LOCATE(concat(repos_id,'Trunk/'), t.path) <> 0 and TO_DAYS(now()) - TO_DAYS(t.date) <= 1
	group by concat(repos_id,'Trunk/'); 
	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done=1;
	open cur_1;
		fetch cur_1 into repos_id, repos_name;
		while done = 0 do
			open cur_2;	
			fetch cur_2 into added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,repos_path,statdate,end_revision,start_revision,main_repos;
			
			while done <> 1 do
			insert into rp_repos_code_count(added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,repos_id,statdate,repos_path,repos_name,is_trunk,end_revision,start_revision,week,main_repos) 
				values(added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,repos_id,statdate,repos_path,repos_name,0,end_revision,start_revision,week(statdate),main_repos); 
			commit;
			fetch cur_2 into added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,repos_path,statdate,end_revision,start_revision,main_repos;
			end while;			
			close cur_2;
			
			SET done = 0;
			open cur_3;	
			fetch cur_3 into added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,repos_path,statdate,end_revision,start_revision,main_repos;
			
			while done <> 1 do
			insert into rp_repos_code_count(added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,repos_id,statdate,repos_path,repos_name,is_trunk,end_revision,start_revision,week,main_repos) 
				values(added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,repos_id,statdate,'Trunk',repos_name,1,end_revision,start_revision,week(statdate),main_repos); 
			commit;
			fetch cur_3 into added_lines,modified_lines,deleted_lines,changed_blank_lines,changed_comment_lines,changed_nbnc_lines,repos_path,statdate,end_revision,start_revision,main_repos;
			end while;			
			close cur_3;
			SET done = 0;
			fetch cur_1 into repos_id, repos_name;
		end while;
	close cur_1;	
end
$$
DELIMITER ;

--模块代码统计定时器
drop event if exists `P_COUNT_REPOS_CODE`;
create event if not exists `P_COUNT_REPOS_CODE`
on schedule every 1 DAY 
starts date_format('2016-07-03 01:00:00','%Y-%m-%d %T') 
on completion preserve 
enable 
comment 'Do code count for repos interval every 1 day' 
do call P_COUNT_REPOS_CODE();

--员工代码统计定时器
drop event if exists `P_COUNT_STAFF_CODE`;
create event if not exists `P_COUNT_STAFF_CODE`
on schedule every 1 DAY 
starts date_format('2016-07-03 02:00:00','%Y-%m-%d %T') 
on completion preserve 
enable 
comment 'Do code count for staff interval every 1 day' 
do call P_COUNT_STAFF_CODE();
