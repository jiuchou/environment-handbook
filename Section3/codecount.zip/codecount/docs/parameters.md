# 参数说明

```
--svn-post-commit
    SVN提交(post commit)代码行统计(仅在“SVN提交”时有效)
-e  (svn-post-commit USE ONLY)
    网络设备，如:eth0(仅在“SVN提交”时有效)
-p  (svn-post-commit USE ONLY)
    版本库路径(服务器端数据路径)(仅在“SVN提交”时有效)
-r  (svn-post-commit USE ONLY)
    待统计的版本(仅在“SVN提交”时有效)
-s  (svn-post-commit USE ONLY)
    svnlook命令所在路径(仅在“SVN提交”时有效)
--end-revision (optional, svn-post-commit USE ONLY)
    同用于带统计至结束版本之间的版本批量统计(可选，仅在“SVN提交”时有效)
    请注意，该值必须大于待统计的版本
-c --count-only  FILE/DIR
    仅仅对一个文件或者目录完成统计代码行的功能，没有比较对象
    这样代码包/文件参数的数量只能有一个(文件或目录)
--ignore-filename-case  (DIFF USE ONLY)
    在比较的时候，忽略文件名的大小写差异(缺省情况会作为两个完全不同的文件)
    (仅在“差异统计”时有效)
--ignore-white-space  (DIFF USE ONLY)
    在比较的时候，忽略代码行中仅仅由于空格(包括制表符)造成的差异(仅在“差异统计”时有效)
--print-lines-info  (DEBUG USE ONLY)
    输出每个文件差异比较后的差异结果和初步统计信息（逐行),主要用于分析错误 
    注意不要针对大型代码包使用，否则逐行打印时间消耗惊人(仅在调试时使用)
--print-files-info
    使用这个开关，当每个文件差异比较和统计以后，输出该文件差异统计的结果信息
    缺省不打印每个文件的信息，只打印最后的结果
    Tips: 上边两个开关都需要打印控制台，如果文件较多的话，打印的时间会很长
            因此除非有具体分析需要，否则尽量不要打开
--force-parse-all  (DIFF USE ONLY)
    对可能相同的文件不进行分析处理，缺省对完全相同的文件会使用比较功能
    仅在“差异统计”时有效，代码行统计(count-only)时所有文件都要处理
--for-program-reading
    改变输出方式，以格式化文本形式输出，便于其他程序读取结果信息
    在由第三方程序调用diffcount，并需要读取统计结果的时候使用
    该选项会屏蔽 --print-lines-info 选项
-v  --version
    输出当前的版本信息
--help
    输出缺省帮助信息
--cn-help
    输出中文帮助信息
--langs
    输出支持的编程语言列表
```

