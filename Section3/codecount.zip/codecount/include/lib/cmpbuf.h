
size_t block_read (int, char *, size_t);
size_t buffer_lcm (size_t, size_t, size_t);
