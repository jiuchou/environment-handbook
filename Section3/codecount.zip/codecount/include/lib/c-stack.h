
#if ! HAVE_SIGINFO_T
# define siginfo_t void
#endif

int c_stack_action (void (*) (int, siginfo_t *, void *));
void c_stack_die (int, siginfo_t *, void *);