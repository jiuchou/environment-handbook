#ifndef _VERSION_H_
#define _VERSION_H_

/* Version Parameter */
extern char const copyright_string[];
extern char const version_string[];

void get_version();

void getVersion();

#endif
